This E-proceedings is cross-platform which allows Windows and Mac users to share the same directory structure and access a common set of files.  

To navigate these E-proceedings a web browser is required - any standards compliant browser should work properly.  

The full-text content on this disk is in Adobe PDF format; pdf viewing software (e.g. Adobe Acrobat Reader) is required to view this content.  

General Instructions: These E-proceedings are set up to run off of the Media, or can be installed onto your hard drive.   

Platform Specific Instructions: 
Windows 98, ME, NT, 2000, XP, Vista and MAC: If this media does not run automatically, navigate to the StartHere.htm file and double click.    

If you click on a .pdf and you receive an error, here's what to do: 

1. Under Edit in your Browser, click on Preferences 

2. Under Preferences, on the left-hand side of the window, click on Receiving Files 

3. Under Receiving Files, click on File Helpers 

4. On the right-hand side of the window, scroll down to Portable Document Format, click on it so that it is highlighted and hit CHANGE 

5. Another window will open, look at the bottom of that window and under the Handling option - How to handle: click on Post-Process with Application Application: Acrobat Reader* 
*If under Application it does not say "Acrobat Reader", hit Browse and look for it on your system. 

6. Hit OK to close window and hit OK again to close preferences window.

*******
